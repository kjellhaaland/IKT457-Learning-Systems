# CIFAR10 and Tsetlin Machine

To run the accuracy tests, run run_tests.py

**Team Accuracy:** 76.3
**Correct:** 7627, **Total:** 10000, **Incorrent:** 2373